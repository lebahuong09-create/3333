// KHO DỮ LIỆU GỒM SÁCH LUYỆN THI VÀ TIỂU THUYẾT CAO CẤP (ẢNH THẬT)
const BOOKS_DATA = [
    {
        id: 1,
        title: "Bộ Đề Luyện Thi Tốt Nghiệp THPT Quốc Gia 2026 - Toàn Diện Toán Học",
        author: "Hội Đồng Sư Phạm HuongVietnam",
        category: "kynang",
        price: 110000,
        oldPrice: 189000,
        image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=400",
        sale: "-42%"
    },
    {
        id: 2,
        title: "Sách - Tiếng Lòng Khó Giấu (Tuyển Tập Văn Học Chiêm Nghiệm Tập 2)",
        author: "Bạch Lạc Mai",
        category: "vanhoc",
        price: 118300,
        oldPrice: 169000,
        image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400",
        sale: "-30%"
    },
    {
        id: 3,
        title: "Cẩm Nang Tư Duy Chiến Lược Cho Học Sinh Luyện Thi Đại Học Khối A B C",
        author: "Nguyễn Doãn Đăng",
        category: "kynang",
        price: 105000,
        oldPrice: 150000,
        image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=400",
        sale: "-30%"
    },
    {
        id: 4,
        title: "Tiểu Thuyết Văn Học Kinh Điển: Người Tìm Vàng Và Kẻ Đi Qua Thung Lũng",
        author: "Paulo Coelho",
        category: "vanhoc",
        price: 95000,
        oldPrice: 140000,
        image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=400",
        sale: "-32%"
    },
    {
        id: 5,
        title: "Chiến Thuật Bứt Phá Điểm Số Cao Cấp Môn Vật Lý & Hóa Học Toàn Tập",
        author: "Thầy Lê Hưởng",
        category: "kynang",
        price: 135000,
        oldPrice: 220000,
        image: "https://images.unsplash.com/photo-1506880018603-83d5b814b5a6?auto=format&fit=crop&q=80&w=400",
        sale: "-38%"
    },
    {
        id: 6,
        title: "Rừng Na Uy - Ấn Bản Đặc Biệt Kỷ Niệm Mùa Hè Rực Lửa",
        author: "Haruki Murakami",
        category: "vanhoc",
        price: 145000,
        oldPrice: 195000,
        image: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&q=80&w=400",
        sale: "-25%"
    }
];

let currentCategory = 'all';
let currentPriceRange = 'all';
let currentSearchQuery = '';
let currentSortOrder = 'default';
let cart = [];

function renderBooks() {
    const booksGrid = document.getElementById('booksGrid');
    if (!booksGrid) return;
    booksGrid.innerHTML = '';

    let filtered = BOOKS_DATA.filter(book => {
        const matchCat = (currentCategory === 'all' || book.category === currentCategory);
        const matchSearch = book.title.toLowerCase().includes(currentSearchQuery.toLowerCase());
        
        let matchPrice = false;
        if (currentPriceRange === 'all') matchPrice = true;
        else if (currentPriceRange === 'under100') matchPrice = book.price < 100000;
        else if (currentPriceRange === '100to200') matchPrice = (book.price >= 100000 && book.price <= 200000);
        else if (currentPriceRange === 'over200') matchPrice = book.price > 200000;

        return matchCat && matchSearch && matchPrice;
    });

    if (currentSortOrder === 'priceAsc') filtered.sort((a,b) => a.price - b.price);
    else if (currentSortOrder === 'priceDesc') filtered.sort((a,b) => b.price - a.price);

    if (filtered.length === 0) {
        booksGrid.innerHTML = `<p style="grid-column:1/-1; text-align:center; color:#999; padding:40px;">Không tìm thấy sản phẩm nào phù hợp!</p>`;
        return;
    }

    filtered.forEach(book => {
        const card = document.createElement('div');
        card.className = 'book-card';
        card.innerHTML = `
            <div class="book-img-box">
                <span class="sale-tag">${book.sale}</span>
                <img src="${book.image}" alt="${book.title}">
            </div>
            <div class="book-info">
                <h3 class="book-title" title="${book.title}">${book.title}</h3>
                <span class="book-author">Tác giả: ${book.author}</span>
                <div class="price-block">
                    <span class="current-price">${book.price.toLocaleString('vi-VN')}đ</span>
                    <span class="old-price">${book.oldPrice.toLocaleString('vi-VN')}đ</span>
                </div>
                <button class="btn-add-cart" onclick="addToCart(${book.id})">
                    <i class="fa-solid fa-cart-plus"></i> THÊM VÀO GIỎ
                </button>
            </div>
        `;
        booksGrid.appendChild(card);
    });
}

function addToCart(bookId) {
    const book = BOOKS_DATA.find(b => b.id === bookId);
    if (!book) return;
    const existing = cart.find(item => item.id === bookId);
    if (existing) existing.quantity += 1;
    else cart.push({ ...book, quantity: 1 });
    updateCartUI();
}

function removeFromCart(bookId) {
    cart = cart.filter(item => item.id !== bookId);
    updateCartUI();
}

function updateCartUI() {
    const cartCount = document.getElementById('cartCount');
    const cartItemCountText = document.getElementById('cartItemCountText');
    const cartItemsList = document.getElementById('cartItemsList');
    const cartTotalCost = document.getElementById('cartTotalCost');

    const totalQty = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.innerText = totalQty;
    cartItemCountText.innerText = totalQty;

    const totalCost = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotalCost.innerText = totalCost.toLocaleString('vi-VN') + "đ";

    if (cart.length === 0) {
        cartItemsList.innerHTML = `<p class="empty-cart-msg">Giỏ hàng trống.</p>`;
        return;
    }

    cartItemsList.innerHTML = '';
    cart.forEach(item => {
        const row = document.createElement('div');
        row.className = 'cart-item';
        row.innerHTML = `
            <img src="${item.image}" class="cart-item-img">
            <div class="cart-item-info">
                <div class="cart-item-title">${item.title}</div>
                <div class="cart-item-price">${item.price.toLocaleString('vi-VN')}đ x ${item.quantity}</div>
            </div>
            <button class="btn-remove-item" onclick="removeFromCart(${item.id})"><i class="fa-solid fa-trash-can"></i></button>
        `;
        cartItemsList.appendChild(row);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    renderBooks();

    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            filterButtons.forEach(b => b.classList.remove('active'));
            const target = e.target.closest('.filter-btn');
            target.classList.add('active');
            currentCategory = target.getAttribute('data-category');
            renderBooks();
        });
    });

    const priceButtons = document.querySelectorAll('.price-btn');
    priceButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            priceButtons.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            currentPriceRange = e.target.getAttribute('data-price');
            renderBooks();
        });
    });

    document.getElementById('searchInput').addEventListener('input', (e) => {
        currentSearchQuery = e.target.value;
        renderBooks();
    });

    document.getElementById('sortSelect').addEventListener('change', (e) => {
        currentSortOrder = e.target.value;
        renderBooks();
    });

    // Toggle Giỏ hàng
    const cartToggle = document.getElementById('cartToggle');
    const closeCart = document.getElementById('closeCart');
    const cartSidebar = document.getElementById('cartSidebar');
    const cartOverlay = document.getElementById('cartOverlay');

    cartToggle.addEventListener('click', () => {
        cartSidebar.classList.add('open');
        cartOverlay.classList.add('open');
    });

    closeCart.addEventListener('click', () => {
        cartSidebar.classList.remove('open');
        cartOverlay.classList.remove('open');
    });

    // Chức năng nút đặt hàng gửi thẳng Zalo
    document.getElementById('checkoutBtn').addEventListener('click', () => {
        if(cart.length === 0) {
            alert('Giỏ hàng chưa có sách anh Hưởng ơi!');
            return;
        }
        let text = "Xin chào Huong BookStore, tôi muốn đặt mua:\n";
        cart.forEach(item => {
            text += `- ${item.title} (SL: ${item.quantity})\n`;
        });
        window.open(`https://zalo.me/0386982366`, '_blank');
    });
});
